from flask import Flask, render_template, request
import pickle
import pandas as pd
import numpy as np
#from sklearn.ensemble import RandomForestClassifier as RFC
#import joblib
app = Flask(__name__)
model = pickle.load(open("studentInfo.pkl", "rb"))
data = pd.read_csv('studentInfo.csv')
@app.route('/')
def home():
    result = ''
    return render_template('upload.html')
@app.route("/predict", methods=["POST","GET"])
def predict():
    if request.method == "POST":
        code_module = str(request.form['code_module'])
        code_presentation = str(request.form[" code_presentation"])
        id_student = str(request.form["id_student "])
        gender = str(request.form["gender"])
        region = str(request.form["region"])
        highest_qualification = str(request.form[" highest_qualification "])
        imd_band = str(request.form["imd_band"])
        num_of_prev_attempts = str(request.form["num_of_prev_attempts"])
        studied_credits = str(request.form["studied_credits"])
        disability = str(request.form["disability"])
        result = model.predict([[code_module,code_presentation,id_student,gender,region,highest_qualification,imd_band ,num_of_prev_attempts,studied_credits,disability]])[0]
        if result == 'Pass or Distinction':
            prediction = "Pass"
        else:
            prediction = 'Fail'
    return render_template('predict.html',prediction = result)
if __name__ == "__main__":
    app.run(debug=True)
